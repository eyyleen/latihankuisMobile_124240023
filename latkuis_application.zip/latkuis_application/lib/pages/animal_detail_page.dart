import 'package:flutter/material.dart';

import '../models/animal.dart';
import '../widgets/tag.dart';

class AnimalDetailPage extends StatelessWidget {
  final Animal animal;
  const AnimalDetailPage({super.key, required this.animal});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          animal.name,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Hero(
              tag: animal.name,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  animal.image,
                  height: 220,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (c, e, s) => const SizedBox(
                    height: 220,
                    child: Center(child: Icon(Icons.broken_image, size: 48)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Animal Details:',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            _infoRow('Name', animal.name),
            _infoRow('Type', animal.type),
            _infoRow('Height', '${animal.height} cm'),
            _infoRow('Weight', '${animal.weight} kg'),
            const SizedBox(height: 16),
            _sectionTitle('Habitat'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: animal.habitat.map((h) => Tag(h)).toList(),
            ),
            const SizedBox(height: 16),
            _sectionTitle('Animal Activities'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: animal.activities.map((a) => Tag(a)).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      text,
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
    ),
  );

  Widget _infoRow(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(
      children: [
        SizedBox(
          width: 80,
          child: Text(label, style: TextStyle(color: Colors.grey.shade700)),
        ),
        Text(': $value'),
      ],
    ),
  );
}
